from setuptools import setup, find_packages

setup(
    name='pyxml',
    version='0.1',
    packages=find_packages(),
    setup_requires=[
        'pip>=3.11',
    ],
)